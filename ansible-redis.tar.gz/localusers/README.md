This files in this subdirectory supply input needed by the scripts/plays that add/change/delete locally defined cluster users 
