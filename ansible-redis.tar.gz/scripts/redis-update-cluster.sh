# this play can be used to update various cluster setting - as coded, 
# this example will update "email_from" and "smtp_host" which are defined
# as group_vars 
ansible-playbook -i $re_inv/$1 $re_ansbase/playbooks/redis-update-cluster.yaml
