#!/bin/bash
# command line args:
# arg 1 - inventory file
# arg 2 is bdb_uid for bdb to be delete
# arg 3 cluster admin user
# arg 4 admin user password
echo "inventory file: " $re_inv/$1
echo "bdb_id: " $2
ansible-playbook -i $re_inv/$1 \
$re_ansbase/playbooks/redis-delete-database.yaml \
-e "bdb_id=$2 username=$3 password=$4"
