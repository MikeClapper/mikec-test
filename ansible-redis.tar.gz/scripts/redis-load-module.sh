#!/bin/bash
# update a cluster license 
# arg 1 - inventory file
# arg 2 - module zip file
#
if [[ $# -ne 2 ]]; then
  echo "*****************************************************************"
  echo "Usage: $0 <inventory_file> <module.zip>"
  echo "note: the env var 're_inv' should be set to point to the subdir"
  echo "      containing <inventory_file>"
  echo "      <module.zip> - absolute or relative path to module file"
  echo "*****************************************************************"
  exit -1
fi
#
ansible-playbook -i $re_inv/$1 $re_ansbase/playbooks/redis-load-module.yml -e module=$2
