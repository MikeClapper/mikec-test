# create cluster using API - must run redis_install play to install the 
# software on all nodes before running this play
# 
# arg 1 - inventory file - found in subdir indicated by $re_inv
#
if [[ $# -lt 1 ]]; then
  echo "*****************************************************************"
  echo "Usage: $0 <inventory_file>"
  echo "note: the env var 're_inv' should be set to point to the subdir"
  echo "      containing <inventory_file>"
  echo "*****************************************************************"
  exit -1
fi
ansible-playbook -i $re_inv/$1 $re_ansbase/playbooks/redis-create-cluster.yaml
 

