# Delete local control plane user 
# arg 1  inventory file
# arg 2  points to a yaml file with the user name to be deleted
# the example 'localusers/admin-del' will cause the default admin user
# 'Adminstrator' to be deleted 
# CAUTION: do not do that unless you have another admin user defined
ansible-playbook -i $re_inv/$1 redis-delete-local-user.yaml -e@$2 
