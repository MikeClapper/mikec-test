#!/bin/bash
# Install RE, create cluster and update license
# arg 1 - inventory file
# arg 2 - license file
#
if [[ $# -lt 2 ]]; then
  echo "*****************************************************************"
  echo "Usage: $0 <inventory_file> <license_file>"
  echo "note: the env var 're_inv' should be set to point to the subdir"
  echo "      containing <inventory_file>"
  echo "      <license_file> - absolute or relative path to license"
  echo "*****************************************************************"
  exit -1
fi
#
ansible-playbook -i $re_inv/$1 $re_ansbase/playbooks/redis-cluster-setup.yaml -e re_license=$2
