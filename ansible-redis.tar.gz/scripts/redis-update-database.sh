# Update database config using input yaml file - this uses Redis API
# PUT /v1/bdbs - no error checking is done in Ansible
# the add '-vvvv' after 'ansible-playbook' below to see the output of the 
# API call for troubleshooting
#
# command line args:
# arg 1 - inventory file
# arg 2 - database name
# arg 3 - database yaml file
ansible-playbook  -i $re_inv/$1 \
$re_ansbase/playbooks/redis-update-database.yaml -e "bdb_name=$2" -e @$3
