# this play is used to upgrade bdbs and crdbs following a cluster upgrade
# it will report errors for databases already on the latest version but will
# continue to process any remaining databases
# 
if [[ $# -lt 1 ]]; then
  echo "*****************************************************************"
  echo "Usage: $0 <inventory_file>"
  echo "note: the env var 're_inv' should be set to point to the subdir"
  echo "      containing <inventory_file>"
  echo "*****************************************************************"
  exit -1
fi
ansible-playbook -i $re_inv/$1 $re_ansbase/playbooks/redis-upgrade-databases.yaml 
