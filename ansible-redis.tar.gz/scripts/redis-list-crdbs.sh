#!/bin/bash
# use set_north or set_south to set up credentials needed for the API call
# or pass cluster url, user and password as extra vars
# .e.g. -e "clusterAPI=https://<cluster_fqdn>:9443 cluster_user=Admin@rlabs.org"
#
if [[ $# -ne 1 ]]; then
  echo "*****************************************************************"
  echo "Usage: $0 <inventory_file> <license_file>"
  echo "note: the env var 're_inv' should be set to point to the subdir"
  echo "      containing <inventory_file>"
  echo "*****************************************************************"
  exit -1
fi
#
ansible-playbook  $re_ansbase/playbooks/redis-list-crdbs.yaml \
-e "clusterAPI=$clusterAPI clusterUser=$clusterUser clusterPass=$clusterPass"
