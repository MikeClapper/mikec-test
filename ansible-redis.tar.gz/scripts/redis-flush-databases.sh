# DANGER _ DANGER _ DANGER
# this play will FLUSH ALL DATABASES on the cluster
# 
# 
echo "DANGER: this script will flush all databases on this cluster"
echo "Do you want to proceed [y/n]?  "
read answer

while [[ ! $answer =~ ^[yYnN]$ ]]; do
    read -p "Please enter y or n: " answer
done

if [[ $answer =~ ^[yY]$ ]]; then
    echo "As you wish..."
    # Place your code to execute here
else
    echo "Exiting the script."
    exit
fi

if [[ $# -lt 1 ]]; then
  echo "*****************************************************************"
  echo "Usage: $0 <inventory_file>"
  echo "note: the env var 're_inv' should be set to point to the subdir"
  echo "      containing <inventory_file>"
  echo "*****************************************************************"
  exit -1
fi
ansible-playbook -i $re_inv/$1 $re_ansbase/playbooks/redis-flush-databases.yaml 
