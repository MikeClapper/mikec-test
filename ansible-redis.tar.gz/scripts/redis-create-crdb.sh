#!/bin/bash
# you must source 'set_north' or 'set_south' to initialize vars
# providing host and login credentials
# command line arg $1 should point to a file in ./crdbs/
# it will default to 'crdbs/crdb.json'
# if you are using parameter substitution in the json files
# you can supply the db name with the second command line parm
if [[ -n $1 ]]; then
    export re_json=$1
else
    export re_json="testdb.json"
fi
if [[ -n $2 ]]; then
    export re_dbname=$2
else
    export re_dbname="testdb"
fi
echo "will create a crdb using endpoint: " $clusterAPI
echo "with json file: " $re_json
ansible-playbook redis-create-crdb.yaml -e @$extra_vars \
-e "re_json=$1"  \
-e "clusterAPI=$clusterAPI clusterUser=$clusterUser clusterPass=$clusterPass" \
-e "dbname=$re_dbname user1=admin@south-cluster.com password1=rEQGUKkg" \
-e "user2=admin@north-cluster.com password2=f4O74fIY"
