# This playbook will create a 'replica_of' database 
# vars:
#   src_db_name - database name of the source db - add to extra_vars
#   rplc_db_name - dabase name for replica_of - add to extra_vars
#   rplc_yaml - yaml file describing replica_of 
#   
# yaml file pointed to by the env var $databases_file.  
#
# the file 'source.sh' is a template for setting the env vars required.
#
ansible-playbook -i $inventory_file redis-create-replica.yaml \
-e @$extra_vars -e@$rplc_yaml -e "src_db_name=sourcedb src_db_port=12003 rplc_db_name=replica-db rplc_db_port=12100"
