# This scripts will list both ldap mappings and roles for the cluster
# pointed to by the 'inventory_file'
if [[ $# -ne 1 ]]; then
  echo "*****************************************************************"
  echo "Usage: $0 <inventory_file> <ldap_mapping id>"
  echo "note: the env var 're_inv' should be set to point to the subdir"
  echo "      containing <inventory_file>"
  echo "*****************************************************************"
  exit -1
fi
ansible-playbook -i $re_inv/$1 $re_ansbase/playbooks/redis-list-ldap-mapping.yaml 
