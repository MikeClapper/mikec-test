# Update Redis Enterprise using inventory file 
# by default the release applied will be 're_url' defined in the group_vars
# for the selected inventory.  This can be overridden on the command line
# by adding '-e re_url=<url for download>'  (no quotes)
#
# arg 1 - selects the inventory file in ./inventory
#
if [[ $# -ne 1 ]]; then
  echo "*****************************************************************"
  echo "Usage: $0 <inventory_file> [-e 're_url=<download link]'"
  echo "note: the env var 're_inv' should be set to point to the subdir"
  echo "      containing <inventory_file>"
  echo "      re_url is defined in the group_vars file - it can be "
  echo "      overriden using -e 're_url=<download_link>'"
  echo "*****************************************************************"
  exit -1
fi

ansible-playbook -v -i $re_inv/$1  $re_ansbase/playbooks/redis-upgrade2.yaml 
