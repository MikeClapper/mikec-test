# Update local user via API call - /v1/users/{{uid}}
# see API documentation for required yaml format
# add '-vvvv' after 'ansible-playbook' below to see API output
# for debugging
user_file=../localusers/mikec-update.yaml
ansible-playbook -i $inventory_file redis-update-local-user.yaml \
-e@$extra_vars -e @$user_file
