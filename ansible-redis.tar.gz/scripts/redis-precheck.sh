# standalone precheck
#
# arg 1 - selects the inventory file in ./inventory
#
if [[ $# -lt 1 ]]; then
  echo "*****************************************************************"
  echo "Usage: $0 <inventory_file>"
  echo "note: the env var 're_inv' should be set to point to the subdir"
  echo "      containing <inventory_file>"
  echo "*****************************************************************"
  exit -1
fi
echo "inventory: " $re_inv/$1

ansible-playbook -i $re_inv/$1 $re_ansbase/playbooks/redis-precheck.yaml  
