# create local user in Redis cluster control plane
# source.sh can be used to set the environment
# user definition is defined by file pointed to by env var 'user_file'
#
set +x
echo "user_file: " $user_file
cat $user_file
ansible-playbook -i $re_inv/$1 \
$re_ansbase/playbooks/redis-create-local-user.yaml \
-e @$user_file
