# delete mapping of ldap group to redis role - requires the ID of the 
# mapping - IDs can be displayed by 'redis-list-ldap-mapping.sh'
if [[ $# -lt 2 ]]; then
  echo "*****************************************************************"
  echo "Usage: $0 <inventory_file> <ldap_mapping id>"
  echo "note: the env var 're_inv' should be set to point to the subdir"
  echo "      containing <inventory_file>"
  echo "*****************************************************************"
  exit -1
fi
ansible-playbook -i $re_inv/$1 \
$re_ansbase/playbooks/redis-delete-ldap-mapping.yaml \
-e "map_uid=$2"
