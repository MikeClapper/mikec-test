# this script can create multiple databases is one run using a properly 
# formatted input files pointed to by the env vars 'databases_file'
# and 'rplc_yaml' - which is set by source.sh
# an example is 'databases.yaml' - it has additional structure not found 
# in the yaml for creating a single database
# A single db can be created by using the yaml file with only one db in the list
# the 'rplc_yaml' file requires the sourcedb name, sourcedb port and replica 
# db port in order to fetch the password from the sourcedb and create the 
# replica db with the correct endpoint port
# This works good for MVP - improvements can most likely be made
#
ansible-playbook -i $inventory_file redis-create-apat-bdbs.yaml \
-e @$extra_vars -e @$databases_file -e@$rplc_yaml \
-e "src_db_name=sourcedb src_db_port=12003 rplc_db_name=replica-db rplc_db_port=12100"
