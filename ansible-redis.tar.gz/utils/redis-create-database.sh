# This playbook will create a single database from a properly formatted 
# yaml file pointed to by the env var $databases_file.  
# An example is 'util/maple_python.yaml' - the keyword 'item' is 
# required as the name for the yaml stanza - this makes it consistent 
# with the play for creating multiple databases. A single db can also be
# created using 'redis-create-databases.sh' by using a yaml file with only
# on db in the list - that is the easiest way
#
# the file 'source.sh' is a template for setting the env vars required.
#
if [[ $# -ne 2 ]]; then
  echo "*****************************************************************"
  echo "Usage: $0 <inventory_file> <database_file>"
  echo "note: the env var 're_inv' should be set to point to the subdir"
  echo "      containing <inventory_file>"
  echo "      <database file> - properly formatted json for db creation"
  echo "*****************************************************************"
  exit -1
fi
ansible-playbook -i $re_inv/$1 $re_ansbase/playbooks/redis-create-database.yaml \
-e @$2
