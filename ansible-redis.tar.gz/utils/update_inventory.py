#!/Users/mikeclapper/.pyenv/shims/python
#
# Used in the script to start gcp instances
# Will update the ansible inventory file in ~/ansible-redis for
# host that was just started - for the PS ansible bundle there is
# and inventory file named host_vars/<host>.yml - for GCP instances there will
# be an internal (net 10) and an external IP address
#
# this script will check to see if there is already a file for this host
# the hosts_vars file holds other ansible variable some hosts - e.g. hosts that
# have already had Redis installed.   For existing files, check to see if
# 'internal_ip' and 'external_ip' exist - if so, update them - if not add them
# if the host_var file does not exist, create it with this format
# {
# internal_ip: 10.128.0.105,
# external_ip: 34.71.229.160
# }
#     Mike Clapper - 8/20/2024
import os
import sys
import time

#import command line parser - declare parser object as global
import argparse
parser = argparse.ArgumentParser()
incount = 0

def load_args():
  parser.add_argument("-o", help="Output file")
  parser.add_argument("-I", help="inventory location - absolute path to host_vars")
  parser.add_argument("-i", help="internal_ip")
  parser.add_argument("-e", help="external_ip")
  parser.add_argument("-v",help="verbose mode",action="store_true")
  parser.add_argument("-d",help="debug mode",action="store_true")


def update_host_vars(host_vars_file, localtime, internal_ip, external_ip):
  # read in the old file
  with open(host_vars_file, "r") as f:
    thishost = f.readlines()
    f.close()
  print(f"DEBUG: {thishost}")
  with open(host_vars_file, "w") as f:
    f.write("# updated by: " + sys.argv[0] + "\n#" + localtime + "\n")
    for line in thishost:
      if "updated by" in line:
        continue
      if "internal_ip" in line:
        f.write("internal_ip: {}\n".format(internal_ip))
      if "external_ip" in line:
        f.write("external_ip: {}\n".format(external_ip))
  return True


def create_hosts_vars(host_vars_file, localtime, internal_ip, external_ip):
  print("DEBUG: create_hosts_vars")
  with open(host_vars_file, "w") as f:
    f.write("# updated by: " + sys.argv[0] + "\n#    " + localtime + "\n")
    f.write("internal_ip: {}\n".format(internal_ip))
    f.write("external_ip: {}\n".format(external_ip))
    f.close()

  return True

def main():
  localtime = time.asctime()
  # test using 'rich' output
  print("current time: ".format(localtime))
  system,node,release,version,machine = os.uname()
  print("node: {} release: {}\nversion: {}  machine: {}".format(node, release, version, machine))
  load_args()
  args = parser.parse_args()
  print("output file: ".format(args.o))
  if args.v:
    print("verbose = true")
  print("script name: {}".format(sys.argv[0]))
  if (args.d):
    print("Debug: true")

  if "my_host_vars" in os.environ:
    hostvars_path = os.environ["my_host_vars"]
  elif args.i:
    hostvars_path = args.I
  else:
      print("ERROR: you must provide an inventory location")
      print("  export my_host_vars={}".format("/path/to/my_host_vars"))
      sys.exit(1)
  inventory_file = os.path.join(hostvars_path,args.o)
  if (args.d):
      print("host_vars: {}".format(hostvars_path))
      print("inventory_file: {}".format(inventory_file))
  if os.path.exists(inventory_file):
    status = update_host_vars(inventory_file, localtime, args.i, args.e)
  else:
    status = create_hosts_vars(inventory_file, localtime, args.i, args.e)

  if status:
    print("INFO: inventory updated")
  else:
    print("ERROR: inventory update failed")


if __name__ == '__main__':
    main()