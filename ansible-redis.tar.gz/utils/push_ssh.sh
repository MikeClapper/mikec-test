# arg 1 - inventory file
# arg 2 - remote user - for this use case that is also ansible_user
if [[ $# -ne 2 ]]; then
  echo "Usage: $0 inventory_file ansible_user"
fi
ansible-playbook -i $re_inv/$1 $re_ansbase/utils/push_ssh_config.yml -e "hostname=all remuser=$2 ansible_user=$2"
