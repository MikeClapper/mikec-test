#/bin/bash
if [[ $# -ne 2 ]]; then
 echo "Usage: $0 <[ip | fqdn>] bdb_id"
 exit  
fi
#
curl -k  -u "admin@rlabs.org:admin" https://$1:9443/v1/bdbs/$2

