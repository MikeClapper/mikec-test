#create cluster using API - must run redis_install play to install the 
#software on all nodes before running this play
# the second playbook sets the designed node as a quorum node
# the node is designated by adding "quorum_node=<n>" to the first lin
# in inventory - <n> is an integer and can be any node in the cluster, 
# but the designation must be added to the first line in the file
#
ansible-playbook -i $inventory_file redis-create-cluster.yaml -e @$extra_vars -e @$group_vars 
#
ansible-playbook -i $inventory_file redis-set-quorum-node.yaml -e @$extra_vars -e @$group_vars 
