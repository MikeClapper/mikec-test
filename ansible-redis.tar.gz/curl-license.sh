curl -k -vvvv  -u "admin@rlabs.org:admin" https://tf-rocky8:9443/v1/license 
