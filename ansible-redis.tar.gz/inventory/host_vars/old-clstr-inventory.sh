#!/bin/bash
# build the inventory file for ansible playbooks to provision a cluster
# 
if [[ $# -ne 2 ]]; then
 echo "Usage: $0 <nodes basename: e.g. 'tf-dmc-clstr'> <inventory_file>"
 exit  
fi
gcloud compute instances list --filter="labels.owner=mikeclapper" | grep RUNNING | grep $1 | awk '{print $5}' > $2
