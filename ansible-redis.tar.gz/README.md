# Redis Ansible Scripts - Version: 3.0

### Introduction

This package provides scripts and playbooks to manage Redis clusters and databases. Each script corresponds to a top-level playbook that executes multiple roles defined in the 'roles' directory.

### Prerequisites

- Ensure Ansible is installed and configured.
- Ensure you have SSH access to the target machines without requiring a password.
- Set up SSH key-based authentication for seamless connectivity
- Verify SSH access by running `ssh user@target_machine`
- Ensure the ansible user has sudo privileges or root access where necessary.
- Refer to the official Ansible documentation for details on inventory files and dynamic inventory usage.



### **Step 1: Setting Up the Environment**

1. Navigate to the root directory of the package.

2. Source the setbase script to set the base location and inventory file `. ./setbase.sh`
    or `source ./setbase.sh`

3. The `re_inv` environmental variable points to the inventory root directory in the example setup.

4. Set up your Ansible inventory and required environment variables. `group_vars/` and `host_vars`

**Note:** The inventory structure is provided as an example.  The plays will work with existing Ansible installations,
which may implement inventory management in one of the many other ways supported by Ansible.



### **Step 2: Understanding Directory Structure**

- **Scripts Directory** `scripts/`: Contains executable scripts.
- **Playbooks Directory** `playbooks`: Contains top-level `.yml` files that execute roles.
- **Roles Directory** `playbooks/roles/`: Contains individual tasks grouped by function.
- **Inventory Directory** `inventory/`: Stores host and group variable files.
- **Cluster-level variables:** Located in `group_vars/` within the `inventory/` directory.
- **Node-level variables:** Located in `host_vars/` within the `inventory/` directory.



### **Step 3: Best Practices & Considerations**

#### **Disclaimer**

These scripts are provided as working examples of how to use Ansible to provision and maintain Redis clusters and databases. The scripts were developed by the Redis Professional Services team, but they are not officially supported. 
The scripts will almost certainly require modification for use in production environments. 
For example, most enterprises will require enhancements for security—the cluster credentials in these examples appear in clear text in the `group_vars` files. In practice, the credentials would be sourced from a secure source, such as Hashicorp Vault.
<p>
Similarly, in practice, there would likely be more error checking and retry logic. These examples are kept as simple as possible for clarity—they are not intended to be production-grade since each enterprise will have its own, often very specific, requirements.

Customers have used these examples as a basis for implementation in Ansible Tower. That implementation is beyond the scope of this package. The use of the 'roles' structure allows plays to be mixed and matched in top-level playbooks.

Here are some **best practices:**

- **Security Enhancements:** Ensure credentials are stored securely, such as in Hashicorp Vault.
- **Error Handling:** Implement additional error checking and retry logic for production use.
- **Custom Implementations:** Adapt scripts as needed to fit enterprise-specific requirements.
- **Ansible Tower/AAP2 Integration:** These scripts can be used as a base for implementation in Ansible Tower or AAP2, though further adaptation may be required.



### **Step 4: Scripts used to execute provided plays**

#### **Cluster Management**

| Script                    | Description                           | Notes                                            |
| ------------------------- | :------------------------------------ | ------------------------------------------------ |
| `redis-create-cluster.sh` | Creates a Redis cluster using the API | Driven by environment variables from `source.sh` |
| `redis-upgrade.sh`        | Upgrades the cluster (not databases)  | Apply new Redis Enterprise version               |
| `redis-update-cluster.sh` | Updates cluster configuration via API | Requires JSON input                              |
| `redis-quorum_node.sh`    | Sets quorum node by ID                | Must be done before provisioning databases       |



#### **Database Management**

| Script                       | Description                       | Notes                                                      |
| ---------------------------- | --------------------------------- | ---------------------------------------------------------- |
| `redis-create-database.sh`   | Creates a single Redis database   | Requires JSON input (e.g., `databases/walnut_single.json`) |
| `redis-create-databases.sh`  | Creates multiple Redis databases  | Requires YAML input (e.g., `databases/databases.yaml`)     |
| `redis-delete-database.sh`   | Deletes a database using `bdb_id` | Use `rladmin status` to find `bdb_id`                      |
| `redis-delete-db-name.sh`    | Deletes a database by name        | Case-sensitive match required                              |
| `redis-update-database.sh`   | Updates database configuration    | Requires YAML input                                        |
| `redis-upgrade-databases.sh` | Upgrades all CRDBs and BDBs       | To be run after a cluster upgrade                          |



#### **User and Access Management**

| Script                         | Description                                 | Notes                                                        |
| ------------------------------ | ------------------------------------------- | ------------------------------------------------------------ |
| `redis-create-local-user.sh`   | Creates a local user in Redis control plane | Example input: `localusers/mikec.yaml`                       |
| `redis-delete-local-user.sh`   | Deletes a local user                        | Only `name` is required in the input YAML                    |
| `redis-update-local-user.sh`   | Updates a local control plane user          | Requires user UID                                            |
| `redis-add-ldap-mapping.sh`    | Maps an LDAP group to a Redis role          | Use `redis-list-ldap-mapping.sh` to find role ID             |
| `redis-delete-ldap-mapping.sh` | Deletes an LDAP mapping using mapping ID    | Use `redis-list-ldap-mapping.sh` to get ID                   |
| `redis-ldap-update.sh`         | Updates LDAP configuration                  | Example input: `json/ldap.json`                              |
| `redis-updt-ldap-mapping.sh`   | Updates LDAP group-to-role mapping          | Requires `map_uid`                                           |
| `redis-list-ldap-mapping.sh`   | List both LDAP mappings and Redis roles     | Provides IDs for roles and mappings                          |
|                                |                                             |                                                              |
| **CRDB**                       |                                             |                                                              |
| `redis-create-crdbs.sh`        | Creates CRDBs                               | CRDB defined by JSON body in ./CRDBS                         |
| `redis-delete-crdb.sh`         | Delete a CRDB                               | Requires CRDB ID; use crdb-cli or redis-list-crdbs.sh to obtain ID |
| `redis-list-crdb.sh`           | List all CRDBs on a cluster                 | Requires only cluster FQDN and login credentials             |



#### **Miscellaneous Operations**

| Script                            | Description                                           | Notes                                          |
| --------------------------------- | ----------------------------------------------------- | ---------------------------------------------- |
| `redis-install.sh`                | Installs Redis Enterprise on nodes                    | Used with Redis Enterprise versions 5.x - 7.2  |
| `redis-uninstall.sh`              | Removes Redis Enterprise from nodes                   | Uses `rl_uninstall.sh`                         |
| `redis-update-certs.sh`           | Updates cluster certificates                          | Format of directory has changed                |
| `redis-update-license.sh`         | Updates the license file                              | License is selected by an environment variable |
| `redis-print-vars.sh`             | Prints Ansible variables for a specific host          | Useful for debugging                           |
| `redis-print-version.sh`          | Displays version tags from `group_vars/all/main.yaml` | For version control                            |
| `redis-setup-singlenode-clstr.sh` | Install RE, create cluster, update license            | Example of multiple roles in a single playbook |